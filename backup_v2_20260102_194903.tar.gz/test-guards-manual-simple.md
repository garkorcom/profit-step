# 🧪 Простой Мануальный Тест V2 Guards

**Время выполнения**: 3-5 минут
**Требования**: Firebase Console доступ

---

## ✅ ШАГ 1: Откройте Firestore Console

```bash
open "https://console.firebase.google.com/project/profit-step/firestore/data/users"
```

---

## ✅ ШАГ 2: Создайте Тестового Пользователя

**В Firestore Console:**

1. Нажмите **"Start collection"** → выберите коллекцию `users`
2. Нажмите **"Add document"**
3. **Document ID**: `test-guards-manual`
4. **Добавьте поля**:

```
email: "test-guards@example.com" (string)
displayName: "Test Guards User" (string)
lastSeen: (timestamp) [выберите текущее время]
loginCount: 0 (number)
status: "active" (string)
companyId: "test-company-123" (string)
createdAt: (timestamp) [выберите текущее время]
```

5. Нажмите **"Save"**

---

## ✅ ШАГ 3: Обновите lastSeen (Trigger Function)

**Подождите 2 секунды**, затем:

1. В том же документе `test-guards-manual`
2. Нажмите **"Edit"** (карандаш)
3. Найдите поле `lastSeen`
4. Измените timestamp на текущее время (нажмите на часы справа)
5. Нажмите **"Update"**

**Это должно запустить `incrementLoginCount_v2`!**

---

## ✅ ШАГ 4: Подождите 10 Секунд

Ожидаем выполнения Cloud Function...

```
⏳ 10 секунд...
```

---

## ✅ ШАГ 5: Проверьте Результаты

### 5.1 Проверьте loginCount

**В Firestore Console:**
1. Обновите страницу (F5)
2. Откройте документ `test-guards-manual`
3. **Проверьте:**

```
✅ loginCount: 1 (было 0)
✅ lastModifiedBy: "incrementLoginCount_v2"
✅ lastModifiedAt: (recent timestamp)
```

**Если loginCount = 1 → Guards работают! 🎉**

---

### 5.2 Проверьте processedEvents

**В Firestore Console:**
1. Перейдите в коллекцию `processedEvents`
2. Найдите последние документы
3. **Должны увидеть:**

```
eventId: (random string)
functionName: "incrementLoginCount_v2"
timestamp: (recent timestamp)
```

**Если документы есть → EventId tracking работает! 🎉**

---

## ✅ ШАГ 6: Проверьте Логи

Откройте терминал и запустите:

```bash
firebase functions:log --only incrementLoginCount_v2 | grep "Guard\|✅\|⏩" | head -20
```

**Ожидаемый результат:**
```
✅ Field Guard: lastSeen changed (xxx → yyy)
✅ Full Guard: All checks passed for incrementLoginCount_v2
✅ incrementLoginCount_v2: Login count incremented for user test-guards-manual
```

---

## ✅ ШАГ 7: Тест EventId Guard (Повторное Обновление)

**Теперь проверим, что EventId Guard блокирует дубликаты:**

1. Снова обновите `lastSeen` в документе `test-guards-manual`
2. Подождите 10 секунд
3. Обновите страницу

**Проверьте loginCount:**
- Если `loginCount = 1` → EventId Guard работает! 🎉 (блокирует повторы)
- Если `loginCount = 2` → Нормально (разные eventId)

---

## ✅ ШАГ 8: Cleanup

**Удалите тестового пользователя:**

1. В Firestore Console → `users` → `test-guards-manual`
2. Нажмите **"Delete document"**
3. Подтвердите удаление

---

## 🎯 ОЖИДАЕМЫЕ РЕЗУЛЬТАТЫ

### ✅ Успешный Тест

- [x] loginCount увеличился с 0 до 1
- [x] lastModifiedBy = "incrementLoginCount_v2"
- [x] processedEvents содержит новые документы
- [x] В логах есть Guard messages (⏩ или ✅)

### ❌ Если Тест Не Прошёл

**Проблема 1: loginCount не изменился**

**Причины:**
1. Функция ещё выполняется (подождите ещё 10 сек)
2. Функция не запустилась (проверьте Firestore rules)
3. Guard заблокировал выполнение (проверьте логи)

**Решение:**
```bash
# Проверьте логи на ошибки
firebase functions:log --only incrementLoginCount_v2 | head -50

# Проверьте статус функции
firebase functions:list | grep incrementLoginCount_v2
```

---

**Проблема 2: processedEvents пустая**

**Причины:**
1. EventId Guard не записывает события (баг)
2. Firestore rules блокируют запись
3. Функция не выполнилась

**Решение:**
```bash
# Проверьте Firestore rules
cat firestore.rules

# Должно быть:
# match /processedEvents/{eventId} {
#   allow read, write: if request.auth != null;
# }
```

---

**Проблема 3: Логи не показывают Guard messages**

**Причины:**
1. V2 функция не развёрнута (используется V1)
2. Логи ещё не обновились

**Решение:**
```bash
# Проверьте какие функции развёрнуты
firebase functions:list

# Должна быть incrementLoginCount_v2, не incrementLoginCount
```

---

## 🎉 ТЕСТ ЗАВЕРШЁН!

Если всё прошло успешно:
- ✅ V2 Guards работают корректно
- ✅ EventId tracking активен
- ✅ Защита от infinite loops включена
- ✅ Система готова к production использованию

**Следующий шаг**: Настройте бюджет $10/день и мониторьте 24-48 часов.

---

**Создано**: 2025-11-06
**Статус**: 🧪 **MANUAL TEST READY**
