# 📧 Настройка Email для приглашений пользователей

Это руководство поможет настроить автоматическую отправку email при приглашении новых пользователей в систему Profit Step.

## 📋 Оглавление

1. [Обзор](#обзор)
2. [Вариант 1: Brevo (рекомендуется для production) ⭐](#вариант-1-brevo-рекомендуется-для-production-)
3. [Вариант 2: Gmail (для разработки)](#вариант-2-gmail-для-разработки)
4. [Вариант 3: Другие SMTP провайдеры](#вариант-3-другие-smtp-провайдеры)
5. [Тестирование](#тестирование)
6. [Troubleshooting](#troubleshooting)

---

## Обзор

Система отправляет email приглашения с помощью Nodemailer. Для этого нужно настроить SMTP соединение.

**Что происходит при приглашении пользователя:**
1. Создается аккаунт в Firebase Auth
2. Создается профиль в Firestore
3. Генерируется ссылка для установки пароля
4. Отправляется красивый HTML email с инструкциями

**Если email не настроен:**
- Пользователь все равно будет создан
- Администратор получит ссылку в UI и сможет отправить ее вручную
- В логах будет видно, что email отправка пропущена

---

## Вариант 1: Brevo (рекомендуется для production) ⭐

### Преимущества Brevo:
- ✅ **300 бесплатных писем в день** (лучше SendGrid!)
- ✅ Высокая доставляемость
- ✅ Простая настройка
- ✅ Аналитика доставки
- ✅ Поддержка на русском языке
- ✅ Без кредитной карты для регистрации

### Шаг 1: Создайте аккаунт Brevo

1. Зарегистрируйтесь на https://www.brevo.com
2. Подтвердите email
3. Заполните основную информацию о компании

### Шаг 2: Получите SMTP учетные данные

1. Перейдите в **SMTP & API**: https://app.brevo.com/settings/keys/smtp
2. Найдите раздел **SMTP**
3. Скопируйте данные:
   - **SMTP server**: `smtp-relay.brevo.com`
   - **Port**: `587`
   - **Login**: ваш email для входа в Brevo
   - **SMTP key**: нажмите "Create a new SMTP key" если ключа еще нет

### Шаг 3: Настройте Firebase Functions

#### Способ A: Firebase Config (Production)

```bash
firebase functions:config:set \
  email.host="smtp-relay.brevo.com" \
  email.port="587" \
  email.user="your-brevo-login@example.com" \
  email.password="ваш-brevo-smtp-key"
```

#### Способ B: .env файл (Local Development)

Создайте файл `functions/.env`:

```bash
EMAIL_HOST=smtp-relay.brevo.com
EMAIL_PORT=587
EMAIL_USER=your-brevo-login@example.com
EMAIL_PASSWORD=ваш-brevo-smtp-key
```

### Шаг 4: Верифицируйте отправителя (опционально, но рекомендуется)

1. Перейдите в **Senders & IP**: https://app.brevo.com/senders
2. Добавьте ваш email как отправителя
3. Подтвердите ownership через email

### Шаг 5: Проверьте настройки

```bash
# Просмотр текущих настроек
firebase functions:config:get

# Разверните функции
firebase deploy --only functions
```

---

## Вариант 2: Gmail (для разработки)

### ⚠️ Внимание
Gmail подходит только для разработки и тестирования. Для production используйте Brevo или другой транзакционный email сервис.

### Шаг 1: Создайте App Password в Google

1. Откройте https://myaccount.google.com/
2. Перейдите в **Security** → **2-Step Verification**
3. Включите двухфакторную аутентификацию, если еще не включена
4. Вернитесь в **Security** → **App passwords** (https://myaccount.google.com/apppasswords)
5. Выберите:
   - App: **Mail**
   - Device: **Other** (введите "Profit Step")
6. Нажмите **Generate**
7. Скопируйте сгенерированный пароль (16 символов без пробелов)

### Шаг 2: Настройте переменные окружения

#### Локальная разработка

Создайте файл `.env` в папке `functions/`:

```bash
# functions/.env
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password-here
```

#### Для Firebase Functions (production)

```bash
firebase functions:config:set \
  email.host="smtp.gmail.com" \
  email.port="587" \
  email.user="your-email@gmail.com" \
  email.password="your-app-password-here"
```

---

## Вариант 3: Другие SMTP провайдеры

### SendGrid

```bash
firebase functions:config:set \
  email.host="smtp.sendgrid.net" \
  email.port="587" \
  email.user="apikey" \
  email.password="your-sendgrid-api-key"
```

**Примечание:** SendGrid дает только 100 писем/день бесплатно, Brevo дает 300.

### Mailgun

```bash
firebase functions:config:set \
  email.host="smtp.mailgun.org" \
  email.port="587" \
  email.user="postmaster@your-domain.mailgun.org" \
  email.password="your-mailgun-password"
```

### AWS SES

```bash
firebase functions:config:set \
  email.host="email-smtp.us-east-1.amazonaws.com" \
  email.port="587" \
  email.user="your-ses-smtp-username" \
  email.password="your-ses-smtp-password"
```

### Mailjet

```bash
firebase functions:config:set \
  email.host="in-v3.mailjet.com" \
  email.port="587" \
  email.user="your-mailjet-api-key" \
  email.password="your-mailjet-secret-key"
```

---

## Тестирование

### 1. Проверьте переменные окружения

```bash
# Firebase Functions
firebase functions:config:get

# Локально (в .env файле)
cat functions/.env
```

### 2. Проверьте логи функций

```bash
# Просмотр логов в реальном времени
firebase functions:log --only inviteUser

# Или в Firebase Console
# https://console.firebase.google.com → Functions → Logs
```

### 3. Протестируйте приглашение

1. Откройте приложение
2. Войдите как администратор
3. Перейдите в **Управление командой**
4. Нажмите **Пригласить участника**
5. Заполните форму и отправьте

**Ожидаемый результат:**
- Зеленое сообщение: "Email с инструкциями отправлен"
- Письмо приходит на указанный email
- В логах: `✅ Invitation email sent to: user@example.com`
- В логах: `📧 Email настроен: smtp-relay.brevo.com:587`

### 4. Проверьте email

Письмо должно содержать:
- ✅ Приветствие с именем пользователя
- ✅ Информацию о роли и компании
- ✅ Кнопку "Установить пароль"
- ✅ Инструкции из 3 шагов
- ✅ Предупреждение о сроке действия ссылки

---

## Troubleshooting

### Проблема: "Email не был отправлен: invalid login"

**Причина:** Неверные учетные данные

**Решение для Brevo:**
1. Проверьте, что используете правильный Login (ваш email входа в Brevo)
2. Проверьте, что SMTP key правильно скопирован
3. Убедитесь, что нет лишних пробелов

```bash
# Пересоздайте конфигурацию
firebase functions:config:unset email
firebase functions:config:set \
  email.host="smtp-relay.brevo.com" \
  email.port="587" \
  email.user="your-email@example.com" \
  email.password="ваш-smtp-key"
firebase deploy --only functions
```

**Решение для Gmail:**
1. Проверьте EMAIL_USER и EMAIL_PASSWORD
2. Убедитесь, что используете App Password, а не обычный пароль
3. Проверьте, что email и пароль не содержат лишних пробелов

### Проблема: "Email отправка не настроена"

**Причина:** Переменные окружения не заданы

**Решение:**
```bash
# Проверьте конфигурацию
firebase functions:config:get

# Если пусто, настройте для Brevo:
firebase functions:config:set \
  email.host="smtp-relay.brevo.com" \
  email.port="587" \
  email.user="your-email@example.com" \
  email.password="ваш-smtp-key"

# Разверните снова
firebase deploy --only functions
```

### Проблема: Email уходит в SPAM

**Решение:**
1. Используйте Brevo или другой транзакционный сервис вместо Gmail
2. Верифицируйте отправителя в Brevo
3. Настройте SPF, DKIM записи для вашего домена (в настройках Brevo)
4. Убедитесь, что email содержит правильный текстовый вариант

### Проблема: Ошибка "ECONNREFUSED"

**Причина:** Не удается подключиться к SMTP серверу

**Решение:**
1. Проверьте HOST и PORT
2. Убедитесь, что сервер доступен:
   ```bash
   telnet smtp-relay.brevo.com 587
   ```
3. Проверьте брандмауэр/firewall

### Проблема: Email не приходит, но в логах успех

**Решение:**
1. Проверьте папку SPAM
2. Подождите 5-10 минут
3. Проверьте, что sender верифицирован (для Brevo)
4. Проверьте квоты отправки (300/день для Brevo)

---

## 🔒 Безопасность

### Важные рекомендации:

1. **Никогда не коммитьте пароли**
   - Добавьте `functions/.env` в `.gitignore`
   - Используйте Firebase Config для production

2. **Используйте SMTP ключи**
   - Для Brevo используйте SMTP key, не пароль аккаунта
   - Для Gmail обязательно App Password

3. **Ограничьте доступ к ключам**
   - SMTP ключи храните в Firebase Config
   - Регулярно ротируйте ключи

4. **Мониторьте использование**
   - Следите за лимитами отправки (300/день для Brevo)
   - Настройте алерты в Brevo при достижении лимита

---

## 📚 Дополнительные ресурсы

- [Nodemailer Documentation](https://nodemailer.com/about/)
- [Brevo SMTP Setup](https://help.brevo.com/hc/en-us/articles/209462765-How-can-I-use-Brevo-SMTP)
- [Gmail App Passwords](https://support.google.com/accounts/answer/185833)
- [Firebase Functions Config](https://firebase.google.com/docs/functions/config-env)

---

## 🆘 Помощь

Если возникли проблемы:

1. Проверьте логи: `firebase functions:log --only inviteUser`
2. Убедитесь, что переменные окружения установлены: `firebase functions:config:get`
3. Протестируйте локально с `.env` файлом
4. Проверьте статус Brevo: https://status.brevo.com/

---

**Готово!** 🎉 Теперь ваши пользователи будут получать красивые приглашения по email с помощью Brevo!

## 📊 Сравнение провайдеров

| Провайдер | Бесплатный лимит | Простота | Доставляемость | Рекомендация |
|-----------|------------------|----------|----------------|--------------|
| **Brevo** | 300/день | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | **Лучший для production** |
| Gmail | нет лимита | ⭐⭐⭐ | ⭐⭐⭐ | Только для dev |
| SendGrid | 100/день | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Хороший, но лимит меньше |
| Mailgun | 100/месяц | ⭐⭐⭐ | ⭐⭐⭐⭐ | Для low-volume |
| AWS SES | 62000/месяц* | ⭐⭐ | ⭐⭐⭐⭐⭐ | Сложная настройка |

*только при отправке с EC2
