# Модуль Аутентификации - Profit Step

## ✅ Реализовано

### 1. Типы и API
- ✅ `src/types/user.types.ts` - Типы для UserProfile, SignUpData, SignInData
- ✅ `src/api/userApi.ts` - API для работы с профилями в Firestore

### 2. Контекст Аутентификации
- ✅ `src/auth/AuthContext.tsx` - Полный функционал:
  - `signUp()` - Регистрация с Email/Password
  - `signIn()` - Вход с Email/Password
  - `signInWithGoogle()` - Вход через Google
  - `signOut()` - Выход из системы
  - `resetPassword()` - Восстановление пароля
  - `currentUser` - Текущий пользователь Auth
  - `userProfile` - Профиль из Firestore
  - `loading` - Состояние загрузки

### 3. Страницы UI
- ✅ `src/pages/auth/LoginPage.tsx` - Страница входа
- ✅ `src/pages/auth/SignupPage.tsx` - Страница регистрации
- ✅ `src/pages/auth/ForgotPasswordPage.tsx` - Восстановление пароля

### 4. Роутинг
- ✅ `src/router/AppRouter.tsx` - Обновлен с:
  - Публичными роутами (/login, /signup, /forgot-password)
  - Защищенными роутами (требуют аутентификации)
  - Автоматическим перенаправлением

### 5. Cloud Functions
- ✅ `functions/src/index.ts`:
  - `onUserCreate` - Автоматически создает профиль в Firestore
  - `onUserDelete` - Очищает данные при удалении аккаунта

### 6. Firestore Rules
- ✅ `firestore.rules` - Правила безопасности:
  - Пользователи работают только со своими данными
  - Профили создаются/удаляются только через Cloud Functions
  - Публичные сметы доступны всем для чтения

## 🚀 Настройка

### Шаг 1: Firebase Configuration

Создайте `.env.local` файл в корне проекта:

```bash
REACT_APP_FIREBASE_API_KEY=your_api_key
REACT_APP_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
REACT_APP_FIREBASE_PROJECT_ID=your_project_id
REACT_APP_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
REACT_APP_FIREBASE_APP_ID=your_app_id
```

### Шаг 2: Firebase Console Setup

1. **Authentication**:
   ```
   Firebase Console → Authentication → Sign-in method
   → Включить Email/Password
   → Включить Google Sign-In
   ```

2. **Firestore Database**:
   ```
   Firebase Console → Firestore Database
   → Create Database (начните в test mode)
   ```

3. **Storage**:
   ```
   Firebase Console → Storage
   → Get Started
   ```

### Шаг 3: Развертывание Cloud Functions

```bash
# Установите Firebase CLI
npm install -g firebase-tools

# Войдите в Firebase
firebase login

# Установите зависимости функций
cd functions
npm install

# Вернитесь в корень проекта
cd ..

# Разверните функции
firebase deploy --only functions
```

### Шаг 4: Развертывание Firestore Rules

```bash
# Разверните правила безопасности
firebase deploy --only firestore:rules
```

### Шаг 5: Запуск приложения

```bash
# Запустите dev сервер
npm start

# Приложение откроется на http://localhost:3001
```

## 📋 Пользовательские Сценарии

### Регистрация нового пользователя

1. Пользователь переходит на `/signup`
2. Заполняет форму (имя, email, пароль)
3. Нажимает "Зарегистрироваться"
4. **На клиенте**:
   - Создается пользователь в Firebase Auth
   - Обновляется displayName в Auth
   - Вызывается `createUserProfile()` для создания профиля в Firestore
5. Пользователь автоматически перенаправляется на главную страницу

### Вход через Google

1. Пользователь нажимает "Войти с Google"
2. Открывается popup Google OAuth
3. Пользователь выбирает аккаунт
4. **На клиенте**:
   - Проверяется существование профиля
   - Если новый пользователь, создается профиль
5. Пользователь перенаправляется на главную

### Восстановление пароля

1. Пользователь переходит на `/forgot-password`
2. Вводит email
3. Нажимает "Отправить ссылку"
4. Firebase отправляет email со ссылкой для сброса
5. Пользователь переходит по ссылке и устанавливает новый пароль

## 🔐 Безопасность

### Firestore Rules

- ✅ Пользователи могут читать/обновлять только свой профиль
- ✅ Создание/удаление профилей только через Cloud Functions
- ✅ Доступ к данным только для владельца
- ✅ Публичные сметы доступны для чтения всем

### Cloud Functions

- ✅ Автоматическое создание профиля при регистрации
- ✅ Автоматическая очистка данных при удалении
- ✅ Предотвращение "осиротевших" данных

## 📊 Структура Данных

### users/{userId}

```typescript
{
  id: string;              // UID из Firebase Auth
  email: string;           // Email (lowercase)
  displayName: string;     // Имя пользователя
  companyId: string;       // ID компании
  role: 'admin' | 'manager' | 'estimator' | 'guest';
  photoURL?: string;       // Аватар
  createdAt: Timestamp;    // Дата создания
  onboarded: boolean;      // Флаг онбординга
}
```

## 🧪 Тестирование

### Проверка регистрации

1. Откройте http://localhost:3001/signup
2. Зарегистрируйте нового пользователя
3. Проверьте:
   - Создался ли пользователь в Firebase Auth
   - Создался ли профиль в Firestore users/{userId}
   - Перенаправление на главную страницу

### Проверка Google Auth

1. Откройте http://localhost:3001/login
2. Нажмите "Войти с Google"
3. Выберите Google аккаунт
4. Проверьте создание профиля для нового пользователя

### Проверка восстановления пароля

1. Откройте http://localhost:3001/forgot-password
2. Введите email зарегистрированного пользователя
3. Проверьте получение email от Firebase

## 🔧 Troubleshooting

### Ошибка: "Firebase API key not configured"

**Решение**: Создайте `.env.local` файл с Firebase credentials

### Ошибка: "Permission denied" при создании профиля

**Решение**:
1. Проверьте, что Cloud Functions развернуты
2. Проверьте Firestore Rules

### Google Auth не работает

**Решение**:
1. Проверьте, что Google Sign-In включен в Firebase Console
2. Добавьте authorized domains в Firebase Console

## 📚 Дополнительные Ресурсы

- [Firebase Authentication Docs](https://firebase.google.com/docs/auth)
- [Cloud Functions Docs](https://firebase.google.com/docs/functions)
- [Firestore Security Rules](https://firebase.google.com/docs/firestore/security/get-started)

## ✨ Следующие Шаги

1. **Онбординг**: Создать флоу для нового пользователя
2. **Профиль**: Страница редактирования профиля
3. **Роли**: Реализовать систему ролей и прав
4. **Email Verification**: Добавить подтверждение email
5. **Multi-tenancy**: Реализовать систему компаний

## 🎯 Готово к использованию!

Модуль аутентификации полностью реализован и готов к использованию. Все основные функции работают:

- ✅ Регистрация Email/Password
- ✅ Вход Email/Password
- ✅ Google Sign-In
- ✅ Восстановление пароля
- ✅ Автоматическое создание профилей
- ✅ Защищенные роуты
- ✅ Firestore Rules

**Приложение запущено на**: http://localhost:3001
